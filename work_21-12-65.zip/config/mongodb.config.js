module.exports = {
    url: 'mongob://127.0.0.1:27017/customercrud'
}